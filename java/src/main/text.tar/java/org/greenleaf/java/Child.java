package org.greenleaf.java;

import java.util.LinkedList;

/**
 * Created by wangyonghua on 2019-09-02.
 */
public class Child extends Parents<java.util.LinkedList> {
    public static void main(String[] args) {
        Child child = new Child();
    }
}
